#!/system/bin/sh
SLEEP_BOOT_WAIT=25
# 目标游戏包名
TARGET_APP="com.tencent.tmgp.dfm"
AUX_SCRIPT_NAME="LinYuKernel.Ver.3.0.2.sh"
AUX_INPUT_DATA="4\n0\n1\n1\n0\n0\n0\n1\n"
FLAG_FILE="/data/local/tmp/dfm_aux_trigger_flag"
CHECK_INTERVAL=2
# ===================================================

# 获取模块路径
MODDIR=${0%/*}
if [ -z "$MODDIR" ] || [ ! -d "$MODDIR" ]; then
    MODDIR="/data/adb/modules/LinYuKernel_tool"
fi
wenjian_DIR="$MODDIR/wenjian"
AUX_SCRIPT="$wenjian_DIR/$AUX_SCRIPT_NAME"

# 日志
LOG_DIR="/data/adb/LinYu日志"
mkdir -p "$LOG_DIR"
chmod 777 "$LOG_DIR"

LOG_AUTO_EXEC="$LOG_DIR/LinYuKernel执行.log"
LOG_DRIVER_EXEC="$LOG_DIR/过验证,驱动执行.log"
LOG_ACTION="/data/adb/LinYu日志/手动执行.log"

echo "=== 开机任务开始: $(date) ===" > "$LOG_DRIVER_EXEC"
echo "=== 辅助脚本日志初始化: $(date) ===" > "$LOG_AUTO_EXEC"

#检测WIFI/移动数据是否可用
check_network_available() {
    # 检测1：检查网络接口是否启用（wlan0=WIFI，rmnet_data0=移动数据，全机型通用）
    WIFI_UP=$(ip link show wlan0 2>/dev/null | grep -q "UP" && echo 1 || echo 0)
    MOBILE_UP=$(ip link show rmnet_data0 2>/dev/null | grep -q "UP" && echo 1 || echo 0)

    # 无任何网络接口启用，直接返回失败
    if [ $WIFI_UP -eq 0 ] && [ $MOBILE_UP -eq 0 ]; then
        return 1
    fi

    # 检测2：Ping公共DNS，验证真正能联网
    ping -c 1 -W 1 223.5.5.5 > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        return 0  # 网络真正就绪
    else
        return 1  # 接口已连，但无法上网
    fi
}
# ===================================================

# --------------- 3. 模式判断 ---------------
MODE_CONFIG="/data/adb/LinYu日志/模式"
if [ -f "$MODE_CONFIG" ]; then
    source "$MODE_CONFIG"
else
    MODE="auto"
    echo "MODE=$MODE" > "$MODE_CONFIG"
fi

if [ "$MODE" = "manual" ]; then
    echo "ℹ️  手动模式，跳过开机自动操作" >> "$LOG_DRIVER_EXEC"
    exit 0
fi

# 驱动加载
# --------------- 网络检测逻辑（无修改，仅依赖修复后的函数） ---------------
echo "[0/3] 等待网络就绪（WIFI/移动数据）..." >> "$LOG_DRIVER_EXEC"
# 循环检测网络，直到可用（每5秒检测一次）
while ! check_network_available; do
    echo "ℹ️  网络尚未就绪，5秒后重试..." >> "$LOG_DRIVER_EXEC"
    sleep 5
done
# 网络就绪后，延迟5秒执行后续操作
echo "✅ 网络就绪，等待5秒后开始执行后续操作..." >> "$LOG_DRIVER_EXEC"
sleep 5
# ===================================================

CONFIG_FILE="/data/adb/LinYu日志/内核版本"
if [ ! -f "$CONFIG_FILE" ]; then
    echo "[错误] 未找到配置文件" >> "$LOG_DRIVER_EXEC"
    exit 1
fi
source "$CONFIG_FILE"

echo "[1/3] 刷新权限..." >> "$LOG_DRIVER_EXEC"
chmod -R 777 "$MODDIR" >> "$LOG_DRIVER_EXEC" 2>&1
chmod -R 777 "/data/adb/" >> "$LOG_DRIVER_EXEC" 2>&1

echo "[2/3] 执行电报验证（强加载模式）..." >> "$LOG_DRIVER_EXEC"
# root校验
if [ "$(whoami)" = "root" ]; then
    echo "✅ 已获取root权限，验证流程启动" >> "$LOG_DRIVER_EXEC"
else
    echo "[错误] 非root权限，验证失败" >> "$LOG_DRIVER_EXEC"
    echo "⚠️  强加载模式：跳过权限错误，继续执行" >> "$LOG_DRIVER_EXEC"
fi
# 验证文件写入
mkdir -p /data/media/0/Android/data/org.telegram.messenger.web/cache
chmod 777 /data/media/0/Android/data/org.telegram.messenger.web/cache
sleep 1
echo "林羽内核" > /data/media/0/Android/data/org.telegram.messenger.web/cache/-6091634025698103321_97.jpg
echo "林羽内核" > /data/media/0/Android/data/org.telegram.messenger.web/cache/-6091634025698103321_99.jpg
echo "林羽内核" > /data/media/0/Android/data/org.telegram.messenger.web/cache/-6089395591818886111_97.jpg
echo "林羽内核" > /data/media/0/Android/data/org.telegram.messenger.web/cache/-6089395591818886111_99.jpg
echo "✅ 电报验证强加载逻辑执行成功" >> "$LOG_DRIVER_EXEC"

# 驱动加载
echo "[3/3] 执行 $VERSION 驱动加载..." >> "$LOG_DRIVER_EXEC"
DRIVER_SCRIPT="$wenjian_DIR/LinYuDriverLoader5.3.sh"
if [ ! -f "$DRIVER_SCRIPT" ]; then
    echo "[错误] 找不到驱动脚本" >> "$LOG_DRIVER_EXEC"
    exit 1
fi
sleep 5
case "$VERSION" in
    "5.10") (echo "1"; sleep 1; echo "1"; sleep 1; echo "Y"; sleep 1) | "$DRIVER_SCRIPT" >> "$LOG_DRIVER_EXEC" 2>&1 ;;
    "5.15") (echo "2"; sleep 1; echo "1"; sleep 1; echo "Y"; sleep 1) | "$DRIVER_SCRIPT" >> "$LOG_DRIVER_EXEC" 2>&1 ;;
    "6.1") (echo "3"; sleep 1) | "$DRIVER_SCRIPT" >> "$LOG_DRIVER_EXEC" 2>&1 ;;
    "6.6") (echo "4"; sleep 1) | "$DRIVER_SCRIPT" >> "$LOG_DRIVER_EXEC" 2>&1 ;;
    "6.12") (echo "5"; sleep 1) | "$DRIVER_SCRIPT" >> "$LOG_DRIVER_EXEC" 2>&1 ;;
    *) echo "[错误] 不支持的版本" >> "$LOG_DRIVER_EXEC"; exit 1 ;;
esac

DRIVER_EXIT_CODE=$?
if [ $DRIVER_EXIT_CODE -eq 0 ]; then
    echo "✅ 驱动加载完成！" >> "$LOG_DRIVER_EXEC"
else
    echo "[错误] 驱动加载失败，返回码: $DRIVER_EXIT_CODE" >> "$LOG_DRIVER_EXEC"
    exit 1
fi

# 静默监听
{
    echo "✅ 监听目标游戏: $TARGET_APP" >> "$LOG_AUTO_EXEC"
    echo "⚠️ 无任何游戏修改操作" >> "$LOG_AUTO_EXEC"
    rm -f "$FLAG_FILE"

    while true; do
        # ==============================================
        GAME_PID=$(pidof "$TARGET_APP")
        
        # 游戏进程存在
        if [ -n "$GAME_PID" ] && [ ! -f "$FLAG_FILE" ]; then
            echo "==============================================" >> "$LOG_AUTO_EXEC"
            echo "📱 检测到游戏运行（PID：$GAME_PID）" >> "$LOG_AUTO_EXEC"
            echo "⏰ 触发时间: $(date)" >> "$LOG_AUTO_EXEC"

            # 【双重校验】执行前再次确认游戏进程存活（杜绝竞态bug）
            if [ -z "$(pidof "$TARGET_APP")" ]; then
                echo "⚠️  游戏已退出，跳过内核执行" >> "$LOG_AUTO_EXEC"
                sleep ${CHECK_INTERVAL}
                continue
            fi

            # 执行内核脚本
            if [ ! -f "$AUX_SCRIPT" ]; then
                echo "[错误] 找不到内核文件: $AUX_SCRIPT" >> "$LOG_AUTO_EXEC"
                sleep ${CHECK_INTERVAL}
                continue
            fi
            chmod +x "$AUX_SCRIPT" 2>/dev/null
            echo "🚀 开始执行内核..." >> "$LOG_AUTO_EXEC"
            printf "$AUX_INPUT_DATA" | "$AUX_SCRIPT" >> "$LOG_AUTO_EXEC" 2>&1

            # 单次游戏运行仅执行一次
            if [ $? -eq 0 ]; then
                echo "✅ 内核执行成功！" >> "$LOG_AUTO_EXEC"
                touch "$FLAG_FILE"
            else
                echo "[错误] 内核执行失败" >> "$LOG_AUTO_EXEC"
            fi
        
        # 游戏进程退出，重置标记
        elif [ -z "$GAME_PID" ] && [ -f "$FLAG_FILE" ]; then
            echo "==============================================" >> "$LOG_AUTO_EXEC"
            echo "📱 游戏进程已退出" >> "$LOG_AUTO_EXEC"
            rm -f "$FLAG_FILE"
            echo "🔄 已重置监听" >> "$LOG_AUTO_EXEC"
        fi

        sleep ${CHECK_INTERVAL}
    done
} &

exit 0