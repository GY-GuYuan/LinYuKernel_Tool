SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

# 配置文件路径
CONFIG_FILE="/data/adb/LinYu日志/内核版本"

# ==================== 可选设置区 ====================
# 强制指定版本：填auto=自动识别内核版本，填版本号=强制使用该版本
# 可选值：auto / 5.10 / 5.15 / 6.1 / 6.6 / 6.12
FORCE_VERSION="auto"
# ===================================================

ui_print "****************************************"
ui_print "林羽内核启动器"
ui_print "by 芊羽 (频道@QianYuHome)"
ui_print "****************************************"

if [ "$FORCE_VERSION" = "auto" ]; then
    # 自动识别当前内核版本
    KERNEL_VERSION=$(uname -r | cut -d '.' -f 1,2)
    ui_print "🔍 自动识别到当前内核版本: $KERNEL_VERSION"
else
    # 强制使用用户指定的版本
    KERNEL_VERSION="$FORCE_VERSION"
    ui_print "ℹ️  已强制指定版本: $KERNEL_VERSION"
fi

# ========== 新增：内核版本提醒逻辑 ==========
if [ "$KERNEL_VERSION" = "5.10" ] || [ "$KERNEL_VERSION" = "5.15" ]; then
    ui_print ""
    ui_print "⚠️  警告：当前内核版本为 $KERNEL_VERSION"
    ui_print "⚠️  当前内核刷入驱动时可能会重启"
    ui_print "⚠️  这是作者问题，别找我，谢谢理解"
    ui_print ""
fi
# ===========================================

case $KERNEL_VERSION in
    5.10|5.15|6.1|6.6|6.12)
    # ==============================================
    mkdir -p "/data/adb/LinYu日志"
    chmod 777 "/data/adb/LinYu日志"
    # ==============================================

    # 写入配置文件
    SELECTED_VERSION="$KERNEL_VERSION"
    echo "VERSION=$SELECTED_VERSION" > "$CONFIG_FILE"

    ui_print "✅ 已自动匹配版本: $SELECTED_VERSION"
    ui_print "✅ 配置已永久保存到 $CONFIG_FILE"
    ;;
    *)
    # 匹配失败，自动使用默认版本
    SELECTED_VERSION="5.10"
    echo "VERSION=$SELECTED_VERSION" > "$CONFIG_FILE"
    ui_print "⚠️  未匹配到对应版本，已自动使用默认版本 5.10"
    ui_print "✅ 配置已永久保存到 $CONFIG_FILE"
    ;;
esac

# 3. 权限设置
ui_print ""
ui_print "🔧 正在设置模块目录权限..."
set_perm_recursive "$MODPATH" 0 0 0755 0777
chmod -R 777 "$MODPATH"
chmod -R 777 "/data/adb/"
chmod -R 777 "$MODPATH/wenjian"
ui_print "✅ 权限设置完成"

# 4. 脚本校验
ui_print ""
ui_print "🔍 正在校验核心脚本..."
if [ -f "$MODPATH/wenjian/LinYuDriverLoader5.2.sh" ]; then
    ui_print "✅ 核心脚本校验通过，安装就绪"
else
    ui_print "警告: wenjian目录缺少核心脚本，请检查文件完整性"
fi

# 5. 完成提示
ui_print ""
ui_print "----------------------------------------"
ui_print "🎉 模块安装完成！"
ui_print "ℹ️  当前生效版本: $SELECTED_VERSION，重启手机后自动执行"
ui_print "ℹ️  如需强制指定版本，修改customize.sh里的FORCE_VERSION参数即可"
ui_print "----------------------------------------"

# 打开telegram进入@QianYuHome频道
am start -a android.intent.action.VIEW \
    -d "tg://resolve?domain=QianYuHome" \
    --user 0 \
    -f 0x10000000 \
    >/dev/null 2>&1