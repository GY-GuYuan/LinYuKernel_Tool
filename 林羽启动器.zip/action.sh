#!/system/bin/sh
MODDIR=${0%/*}

check_volume_key() {
    local key_pressed=""
    local timeout=15
    local count=0
    
    # 获取 getevent 路径
    local GETEVENT=""
    [ -f "/system/bin/getevent" ] && GETEVENT="/system/bin/getevent"
    [ -f "/system/xbin/getevent" ] && GETEVENT="/system/xbin/getevent"
    [ -z "$GETEVENT" ] && command -v getevent >/dev/null 2>&1 && GETEVENT="getevent"
    
    echo "****************************************"
    echo "      三角洲行动深度清理"
    echo "****************************************"
    echo ""
    echo "  警告: 此操作会强制停止游戏并清理缓存"
    echo "         游戏将会被重装，账号需要重新登录"
    echo "         但游戏内下载的数据不会丢失"
    echo ""
    echo "请选择操作:"
    echo "   [音量下] 开始清理并重启"
    echo "   [音量上] 退出脚本"
    echo ""
    
    # 如果没有 getevent，自动继续
    if [ -z "$GETEVENT" ]; then
        echo "  自动开始清理..."
        sleep 5
        return 0
    fi
    
    echo -n "等待按键中"
    
    while [ $count -lt $timeout ]; do
        local event=$($GETEVENT -lc 1 2>/dev/null)
        if echo "$event" | grep -qi "KEY_VOLUMEUP"; then
            echo ""
            echo ""
            echo "✗ 已取消操作"
            return 1
        elif echo "$event" | grep -qi "KEY_VOLUMEDOWN"; then
            echo ""
            echo ""
            echo "✓ 已确认，开始清理..."
            return 0
        fi
        count=$((count + 1))
        echo -n "."
        sleep 1
    done
    
    echo ""
    echo ""
    echo " 超时，自动开始清理"
    return 0
}

# ============================================
# 清理主函数
# ============================================
do_clean() {
    # 结束游戏进程
    process=$(ps -ef | grep "com.tencent.tmgp.dfm" | grep -v grep | awk '{print $2}')
    if [ -n "$process" ]; then
        am force-stop com.tencent.tmgp.dfm
    fi
    
    # 清理主用户数据 (用户0)
    if [ -d "/data/user/0/com.tencent.tmgp.dfm" ]; then
        rm -rf /data/user/0/com.tencent.tmgp.dfm/app_appcache
        rm -rf /data/user/0/com.tencent.tmgp.dfm/app_crashrecord
        rm -rf /data/user/0/com.tencent.tmgp.dfm/app_crashSight
        rm -rf /data/user/0/com.tencent.tmgp.dfm/app_databases
        rm -rf /data/user/0/com.tencent.tmgp.dfm/app_geolocation
        rm -rf /data/user/0/com.tencent.tmgp.dfm/app_midaslib_0
        rm -rf /data/user/0/com.tencent.tmgp.dfm/app_midaslib_1
        rm -rf /data/user/0/com.tencent.tmgp.dfm/app_midasodex
        rm -rf /data/user/0/com.tencent.tmgp.dfm/app_midasplugins
        rm -rf /data/user/0/com.tencent.tmgp.dfm/app_tbs
        rm -rf /data/user/0/com.tencent.tmgp.dfm/app_tbs_64
        rm -rf /data/user/0/com.tencent.tmgp.dfm/app_textures
        rm -rf /data/user/0/com.tencent.tmgp.dfm/app_webview_msdk_inner_webview
        rm -rf /data/user/0/com.tencent.tmgp.dfm/app_webview
        rm -rf /data/user/0/com.tencent.tmgp.dfm/cache
        rm -rf /data/user/0/com.tencent.tmgp.dfm/code_cache
        rm -rf /data/user/0/com.tencent.tmgp.dfm/databases
        rm -rf /data/user/0/com.tencent.tmgp.dfm/shared_prefs
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/ano_tmp
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/app
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/beacon
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/com.gcloudsdk.gcloud.gvoice
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/data
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/perfsight
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/popup
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/qm
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/tbs
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/tdm_tmp
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/shell_cache
        mv /data/user/0/com.tencent.tmgp.dfm/files/UE4Game /data/user/0/com.tencent.tmgp.dfm/files/.UE4Game
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/*
        mv /data/user/0/com.tencent.tmgp.dfm/files/.UE4Game /data/user/0/com.tencent.tmgp.dfm/files/UE4Game
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/.*
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/UE4Game/DeltaForce/Engine
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/UE4Game/DeltaForce/Manifest_UFSFiles_Android.txt
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/UE4Game/DeltaForce/DeltaForce/Config
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/UE4Game/DeltaForce/DeltaForce/Intermediate
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/UE4Game/DeltaForce/DeltaForce/Saved/Gamelet
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/UE4Game/DeltaForce/DeltaForce/Saved/LoadTrack
        rm -rf /data/user/0/com.tencent.tmgp.dfm/files/UE4Game/DeltaForce/DeltaForce/Saved/pixuicache
        rm -rf /data/user/0/com.tencent.tmgp.dfm/app_cn.wsds.sdk.game.data
        echo "清理根目录文件完毕"
        sleep 0.5
        
        rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.dfm/cache
        rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.dfm/files/App.1.201.37103.52
        rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.dfm/files/env
        rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.dfm/files/GVoiceCache
        rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.dfm/files/midas
        rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.dfm/files/pixui
        rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.dfm/files/tbslog
        rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.dfm/files/tencent
        rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.dfm/files/TGPA
        rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.dfm/files/VulkanProgramBinaryCache
        rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.dfm/files/UE4Game/DeltaForce/DeltaForce/Saved/Logs
        rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.dfm/files/.system_android_l2
        rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.dfm/files/nbavmc_unxqbih.dat
        rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.dfm/files/juscrkat.dat
        rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.dfm/files/HANYCJLZOEUS_TOKEN2.dat
        echo "清理内部存储文件完毕"
        sleep 1
        
        # 修改 SSAID (用户0)
        Id_Path=/data/system/users/0
        Id_File=$Id_Path/settings_ssaid.xml
        if [ -f "$Id_File" ]; then
            abx2xml -i "$Id_File" 2>/dev/null
            
            View_id() { grep "$1" "$Id_File" | awk -F '"' '{print $6}'; }
            Random_Id_1() { cat /proc/sys/kernel/random/uuid; }
            Amend_Id() { sed -i "s#$1#$2#g" "$Id_File"; }
            
            Amend_Id "$(View_id userkey)" "$(echo "$(Random_Id_1)$(Random_Id_1)" | tr -d - | tr a-z A-Z)"
            Amend_Id "$(View_id com.tencent.tmgp.dfm)" "$(Random_Id_1 | tr -d - | head -c 16)"
            Pkg_Aid=$(View_id com.tencent.tmgp.dfm)
            
            xml2abx -i "$Id_File" 2>/dev/null
            echo "修改后的id: $Pkg_Aid"
        fi
    fi
    
    # 清理多开用户 (用户999)
    if [ -d "/data/user/999/com.tencent.tmgp.dfm" ]; then
        rm -rf /data/user/999/com.tencent.tmgp.dfm/app_appcache
        rm -rf /data/user/999/com.tencent.tmgp.dfm/app_crashrecord
        rm -rf /data/user/999/com.tencent.tmgp.dfm/app_crashSight
        rm -rf /data/user/999/com.tencent.tmgp.dfm/app_databases
        rm -rf /data/user/999/com.tencent.tmgp.dfm/app_geolocation
        rm -rf /data/user/999/com.tencent.tmgp.dfm/app_midaslib_0
        rm -rf /data/user/999/com.tencent.tmgp.dfm/app_midaslib_1
        rm -rf /data/user/999/com.tencent.tmgp.dfm/app_midasodex
        rm -rf /data/user/999/com.tencent.tmgp.dfm/app_midasplugins
        rm -rf /data/user/999/com.tencent.tmgp.dfm/app_tbs
        rm -rf /data/user/999/com.tencent.tmgp.dfm/app_tbs_64
        rm -rf /data/user/999/com.tencent.tmgp.dfm/app_textures
        rm -rf /data/user/999/com.tencent.tmgp.dfm/app_webview_msdk_inner_webview
        rm -rf /data/user/999/com.tencent.tmgp.dfm/app_webview
        rm -rf /data/user/999/com.tencent.tmgp.dfm/cache
        rm -rf /data/user/999/com.tencent.tmgp.dfm/code_cache
        rm -rf /data/user/999/com.tencent.tmgp.dfm/databases
        rm -rf /data/user/999/com.tencent.tmgp.dfm/shared_prefs
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/ano_tmp
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/app
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/beacon
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/com.gcloudsdk.gcloud.gvoice
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/data
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/perfsight
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/popup
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/qm
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/tbs
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/tdm_tmp
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/shell_cache
        mv /data/user/999/com.tencent.tmgp.dfm/files/UE4Game /data/user/999/com.tencent.tmgp.dfm/files/.UE4Game
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/*
        mv /data/user/999/com.tencent.tmgp.dfm/files/.UE4Game /data/user/999/com.tencent.tmgp.dfm/files/UE4Game
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/.*
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/UE4Game/DeltaForce/Engine
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/UE4Game/DeltaForce/Manifest_UFSFiles_Android.txt
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/UE4Game/DeltaForce/DeltaForce/Config
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/UE4Game/DeltaForce/DeltaForce/Intermediate
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/UE4Game/DeltaForce/DeltaForce/Saved/Gamelet
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/UE4Game/DeltaForce/DeltaForce/Saved/LoadTrack
        rm -rf /data/user/999/com.tencent.tmgp.dfm/files/UE4Game/DeltaForce/DeltaForce/Saved/pixuicache
        rm -rf /data/user/999/com.tencent.tmgp.dfm/app_cn.wsds.sdk.game.data
        echo "清理多开根目录文件完毕"
        sleep 0.5
        
        rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.dfm/cache
        rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.dfm/files/App.1.201.37103.52
        rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.dfm/files/env
        rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.dfm/files/GVoiceCache
        rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.dfm/files/midas
        rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.dfm/files/pixui
        rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.dfm/files/tbslog
        rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.dfm/files/tencent
        rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.dfm/files/TGPA
        rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.dfm/files/VulkanProgramBinaryCache
        rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.dfm/files/UE4Game/DeltaForce/DeltaForce/Saved/Logs
        rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.dfm/files/.system_android_l2
        rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.dfm/files/nbavmc_unxqbih.dat
        rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.dfm/files/juscrkat.dat
        rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.dfm/files/HANYCJLZOEUS_TOKEN2.dat
        echo "清理多开内部存储文件完毕"
        sleep 1
        
        # 修改 SSAID (用户999)
        Id_Path=/data/system/users/999
        Id_File=$Id_Path/settings_ssaid.xml
        if [ -f "$Id_File" ]; then
            abx2xml -i "$Id_File" 2>/dev/null
            
            View_id() { grep "$1" "$Id_File" | awk -F '"' '{print $6}'; }
            Random_Id_1() { cat /proc/sys/kernel/random/uuid; }
            Amend_Id() { sed -i "s#$1#$2#g" "$Id_File"; }
            
            Amend_Id "$(View_id userkey)" "$(echo "$(Random_Id_1)$(Random_Id_1)" | tr -d - | tr a-z A-Z)"
            Amend_Id "$(View_id com.tencent.tmgp.dfm)" "$(Random_Id_1 | tr -d - | head -c 16)"
            Pkg_Aid=$(View_id com.tencent.tmgp.dfm)
            
            xml2abx -i "$Id_File" 2>/dev/null
            echo "修改后的id: $Pkg_Aid"
        fi
    fi
    
    # 重装游戏
    pm path com.tencent.tmgp.dfm | sed -E 's/(.*):(.*)/\2/' | xargs pm install -r --abi arm64-v8a
    echo "重装游戏完毕"
    echo "3秒后即将自动重启"
    sleep 3
    reboot
}


if check_volume_key; then
    do_clean
else
    echo "已退出，未执行任何操作"
    exit 0
fi