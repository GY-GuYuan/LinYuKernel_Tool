#!/system/bin/sh
# 目标应用包名
TARGET_APP="com.tencent.tmgp.dfm"
# 监听服务日志文件，固定在/data/adb/目录下
LOG_FILE="/data/adb/linyu_app_monitor.log"

# 初始化循环间隔，固定2秒一次检测
LOOP_INTERVAL=2

# 精准检测进程函数
check_target_process() {
    ps -ef 2>/dev/null | awk -v app="$TARGET_APP" '$NF == app {print $2}' | grep -q .
    return $?
}

# 初始化启动日志
echo "=== 应用监听服务启动: $(date) ===" > "$LOG_FILE"
echo "目标应用: $TARGET_APP" >> "$LOG_FILE"
echo "日志目录: /data/adb/" >> "$LOG_FILE"

# 无限循环监听
while true; do
    # 进程检测
    if check_target_process; then
        # 仅记录应用启动
        echo "[$(date)] 检测到目标应用启动" >> "$LOG_FILE"
    else
        # 仅记录应用退出
        echo "[$(date)] 检测到目标应用退出" >> "$LOG_FILE"
    fi

    # 按固定2秒间隔
    sleep "$LOOP_INTERVAL"
done